# dolifraispro

Module ajoutant un modèle de document pour les notes de frais de Dolibarr.

Le document de note de frais généré avec le modèle contient les documents liés à la note de frais.
